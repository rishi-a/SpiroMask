#ifndef _LOWPOWER_H_
#define _LOWPOWER_H_

void lowPower();
void lowPowerWait(unsigned long time);
void lowPowerBleWait(unsigned long time);

#endif //_LOWPOWER_H_
